# to only import all necessarry modules/libs define the calling executable
from net.dns import askdns
from net.ssh import SecureSHell
