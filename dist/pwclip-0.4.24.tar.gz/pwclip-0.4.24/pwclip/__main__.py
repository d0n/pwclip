#!/usr/bin/env python3
"""pwclip main module"""
from pwclip import pwcli
pwcli()
