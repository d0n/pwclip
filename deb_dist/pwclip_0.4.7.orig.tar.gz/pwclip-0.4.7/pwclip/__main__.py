#!/usr/bin/env python3

from pwclip import pwclipper
pwclipper()
