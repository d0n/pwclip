"""init of colortext just import all usability functions"""
from colortext.colortext import *
